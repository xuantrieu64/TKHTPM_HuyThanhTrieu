<?php
define('DB_NAME', 'xobjhnrc_dulieudt');
define('DB_USER', 'xobjhnrc_dulieudt');
define('DB_PASSWORD', 'xobjhnrc_dulieudt');
define('DB_HOST', 'localhost');
define('PORT', 3306);
define('DB_CHARSET', 'utf8mb4');
