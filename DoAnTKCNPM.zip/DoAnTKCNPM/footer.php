<!-- Start Footer -->
<footer>
    <div class="container">
        <div class="row-gird">
            <div class="footer-item">
                <p>Thông tin và chính sách</p>
                <p>Đăng ký thành viên</p>
                <p>Mua hàng online</p>
                <p>Chính sách đổi trả</p>
                <p>Chính sách giao hàng</p>
            </div>
            <div class="footer-item">
                <p>Dịch vụ khác</p>
                <p>Chính sách bảo hành</p>
                <p>Tuyển dụng</p>
                <p>Liên kết hợp tác kinh doanh</p>
            </div>
            <div class="footer-item">
                <p>Chăm sóc khách hàng</p>
                <p>Trải nghiệm mua sắm</p>
                <p>Hỏi đáp</p>
            </div>
            <div class="footer-item">
                <p>Địa chỉ liên hệ</p>
                <p>Công ty TNHH HTT và dịch vụ</p>
                <p>Địa chỉ văn phòng: 350-352 Võ Văn Kiệt, Phường Cô Giang, Quận 1, Thành phố Hồ Chí Minh, Việt Nam.
                    Điện thoại: 028.7108.9666</p>
            </div>
        </div>
        <div class="information">
            <div class="information-text">
                Rất vui được gặp bạn!!
            </div>
            <div class="information-icon">
                <i class="fa-brands fa-facebook-f"></i>
                <i class="fa-brands fa-twitter"></i>
                <i class="fa-brands fa-instagram"></i>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer -->